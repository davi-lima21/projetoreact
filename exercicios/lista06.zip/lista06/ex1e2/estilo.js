import { StyleSheet } from "react-native";

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#fff',
    //   alignItems: 'center',
      justifyContent: 'center',
    },
    vermelhinho: {
      color: 'red',
      fontSize: 15,
    },
    azulao: {
        color: 'blue',
        fontSize: 30,
        fontWeight: 'bold',
      },
  });

  export default styles;